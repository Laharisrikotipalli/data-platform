--
-- PostgreSQL database dump
--

\restrict v2AJczgZHi6zlOOy1xJGQTSbCc5B24xOOn2PMjyQC8SjVZ45xES4PqYlYsYlt2T

-- Dumped from database version 13.23
-- Dumped by pg_dump version 13.23

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: products; Type: TABLE; Schema: public; Owner: sourceuser
--

CREATE TABLE public.products (
    product_id integer NOT NULL,
    name character varying(100) NOT NULL,
    category character varying(50) NOT NULL,
    price numeric(10,2) NOT NULL
);


ALTER TABLE public.products OWNER TO sourceuser;

--
-- Name: reviews; Type: TABLE; Schema: public; Owner: sourceuser
--

CREATE TABLE public.reviews (
    review_id integer NOT NULL,
    product_id integer,
    rating integer,
    review_text text
);


ALTER TABLE public.reviews OWNER TO sourceuser;

--
-- Name: sales; Type: TABLE; Schema: public; Owner: sourceuser
--

CREATE TABLE public.sales (
    sale_id integer NOT NULL,
    product_id integer,
    sale_date timestamp without time zone,
    quantity integer,
    total_amount numeric(10,2)
);


ALTER TABLE public.sales OWNER TO sourceuser;

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: sourceuser
--

COPY public.products (product_id, name, category, price) FROM stdin;
1	Laptop Pro 15	Electronics	1299.99
2	Wireless Mouse	Electronics	29.99
3	Ergonomic Desk Chair	Furniture	249.99
4	Coffee Mug XL	Kitchen	14.99
5	USB-C Cable 2m	Electronics	12.99
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: sourceuser
--

COPY public.reviews (review_id, product_id, rating, review_text) FROM stdin;
1	1	5	Excellent laptop
2	2	4	Good mouse
3	3	5	Very comfortable
4	4	4	Nice mug
5	5	5	Durable cable
\.


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: sourceuser
--

COPY public.sales (sale_id, product_id, sale_date, quantity, total_amount) FROM stdin;
1	1	2026-05-21 06:44:05.151305	1	1299.99
2	2	2026-05-21 06:44:05.151305	2	59.98
3	3	2026-05-21 06:44:05.151305	1	249.99
4	4	2026-05-21 06:44:05.151305	3	44.97
5	5	2026-05-21 06:44:05.151305	2	25.98
\.


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: sourceuser
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (product_id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: sourceuser
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (review_id);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: sourceuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (sale_id);


--
-- Name: reviews reviews_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sourceuser
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: sales sales_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sourceuser
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- PostgreSQL database dump complete
--

\unrestrict v2AJczgZHi6zlOOy1xJGQTSbCc5B24xOOn2PMjyQC8SjVZ45xES4PqYlYsYlt2T

