--
-- PostgreSQL database dump
--

\restrict RTkkfdpCPQdfBuomvge0KxZxk4X47XDILPBeqvixO1iM8SW37hnElKM06LXUUPP

-- Dumped from database version 13.23
-- Dumped by pg_dump version 13.23

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: raw; Type: SCHEMA; Schema: -; Owner: warehouseuser
--

CREATE SCHEMA raw;


ALTER SCHEMA raw OWNER TO warehouseuser;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: fact_daily_sales; Type: TABLE; Schema: public; Owner: warehouseuser
--

CREATE TABLE public.fact_daily_sales (
    date date,
    product_id bigint,
    product_name text,
    product_category text,
    total_quantity_sold numeric,
    total_revenue double precision,
    avg_review_rating numeric
);


ALTER TABLE public.fact_daily_sales OWNER TO warehouseuser;

--
-- Name: products; Type: TABLE; Schema: raw; Owner: warehouseuser
--

CREATE TABLE raw.products (
    product_id bigint,
    name text,
    category text,
    price double precision
);


ALTER TABLE raw.products OWNER TO warehouseuser;

--
-- Name: reviews; Type: TABLE; Schema: raw; Owner: warehouseuser
--

CREATE TABLE raw.reviews (
    review_id bigint,
    product_id bigint,
    rating bigint,
    review_text text
);


ALTER TABLE raw.reviews OWNER TO warehouseuser;

--
-- Name: sales; Type: TABLE; Schema: raw; Owner: warehouseuser
--

CREATE TABLE raw.sales (
    sale_id bigint,
    product_id bigint,
    sale_date timestamp without time zone,
    quantity bigint,
    total_amount double precision
);


ALTER TABLE raw.sales OWNER TO warehouseuser;

--
-- Data for Name: fact_daily_sales; Type: TABLE DATA; Schema: public; Owner: warehouseuser
--

COPY public.fact_daily_sales (date, product_id, product_name, product_category, total_quantity_sold, total_revenue, avg_review_rating) FROM stdin;
2026-05-21	1	Laptop Pro 15	Electronics	2	2599.98	4.5000000000000000
2026-05-21	2	Wireless Mouse	Electronics	4	119.96	3.5000000000000000
2026-05-21	3	Ergonomic Desk Chair	Furniture	2	499.98	4.5000000000000000
2026-05-21	4	Coffee Mug XL	Kitchen	6	89.94	4.5000000000000000
2026-05-21	5	USB-C Cable 2m	Electronics	4	51.96	4.0000000000000000
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: raw; Owner: warehouseuser
--

COPY raw.products (product_id, name, category, price) FROM stdin;
1	Laptop Pro 15	Electronics	1299.99
2	Wireless Mouse	Electronics	29.99
3	Ergonomic Desk Chair	Furniture	249.99
4	Coffee Mug XL	Kitchen	14.99
5	USB-C Cable 2m	Electronics	12.99
\.


--
-- Data for Name: reviews; Type: TABLE DATA; Schema: raw; Owner: warehouseuser
--

COPY raw.reviews (review_id, product_id, rating, review_text) FROM stdin;
1	1	5	Excellent laptop very fast and reliable
2	1	4	Great performance but pricey
3	2	3	Average mouse works fine
4	2	4	Good value for money
5	3	5	Very comfortable chair
6	3	4	Good quality but assembly took time
7	4	5	Love this mug dishwasher safe
8	4	4	Design is nice
9	5	3	Works as expected
10	5	5	Very durable cable
11	6	4	Good notebook for work
12	6	5	Perfect for meetings
13	7	5	Amazing display quality
14	7	4	Good monitor for the price
15	8	5	Mechanical keyboard feels great
16	8	4	RGB lighting is nice
17	9	4	Desk mat is very comfortable
18	9	3	Good but cheap build quality
19	10	5	Excellent webcam quality
20	10	4	Clear video and good microphone
\.


--
-- Data for Name: sales; Type: TABLE DATA; Schema: raw; Owner: warehouseuser
--

COPY raw.sales (sale_id, product_id, sale_date, quantity, total_amount) FROM stdin;
1	1	2026-05-21 06:44:05.151305	1	1299.99
2	2	2026-05-21 06:44:05.151305	2	59.98
3	3	2026-05-21 06:44:05.151305	1	249.99
4	4	2026-05-21 06:44:05.151305	3	44.97
5	5	2026-05-21 06:44:05.151305	2	25.98
\.


--
-- PostgreSQL database dump complete
--

\unrestrict RTkkfdpCPQdfBuomvge0KxZxk4X47XDILPBeqvixO1iM8SW37hnElKM06LXUUPP

